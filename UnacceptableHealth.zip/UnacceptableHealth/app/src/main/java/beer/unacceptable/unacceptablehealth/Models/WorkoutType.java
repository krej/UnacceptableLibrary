package beer.unacceptable.unacceptablehealth.Models;

import com.unacceptable.unacceptablelibrary.Models.ListableObject;

public class WorkoutType extends ListableObject {
    @Override
    public String getSingularName() {
        return "Workout Type";
    }
}
