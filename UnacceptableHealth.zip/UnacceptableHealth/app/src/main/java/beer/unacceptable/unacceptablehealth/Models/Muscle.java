package beer.unacceptable.unacceptablehealth.Models;

import com.unacceptable.unacceptablelibrary.Models.ListableObject;

public class Muscle extends ListableObject {

    @Override
    public String getSingularName() {
        return "Muscle";
    }
}
