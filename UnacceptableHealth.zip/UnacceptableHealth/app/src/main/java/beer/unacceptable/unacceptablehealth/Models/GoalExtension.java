package beer.unacceptable.unacceptablehealth.Models;

import com.google.gson.annotations.Expose;

import java.util.Date;

public class GoalExtension {
    @Expose
    public Date OriginalEndDate;
    @Expose
    public Date NewEndDate;

}
