package beer.unaccpetable.brewzilla.Models;

import com.google.gson.annotations.Expose;
import com.unacceptable.unacceptablelibrary.Models.ListableObject;

/**
 * Created by Megatron on 10/25/2017.
 */

public class Adjunct extends ListableObject {
    @Expose
    public String createdByUserId;
}
