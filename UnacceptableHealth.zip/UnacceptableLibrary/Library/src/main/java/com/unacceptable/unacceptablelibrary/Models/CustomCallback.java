package com.unacceptable.unacceptablelibrary.Models;

public interface CustomCallback {
    void Complete(Object o);
}
